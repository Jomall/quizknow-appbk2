#!/bin/bash
echo "Running Next.js build..."
npm run build
