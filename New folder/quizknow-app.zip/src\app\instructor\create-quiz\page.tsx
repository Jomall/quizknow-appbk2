'use client';

import { useRouter } from 'next/navigation';
import FinalCreateQuizPage from './final-page';

export default function CreateQuizPage() {
  return <FinalCreateQuizPage />;
}
